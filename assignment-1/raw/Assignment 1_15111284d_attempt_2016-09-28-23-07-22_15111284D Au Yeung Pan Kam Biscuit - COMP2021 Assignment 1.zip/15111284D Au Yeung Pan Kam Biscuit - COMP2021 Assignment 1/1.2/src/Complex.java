public class Complex {

    // Task 3: add the missing fields


    Complex(double real, double imag){
        // Task 4: complete the constructor

    }

    Complex add(Complex other){
        // Task 4: complete the method

    }

    Complex multiply(Complex other){
        // Task 4: complete the method

    }

    String asString(){
        // Task 4: complete the method

    }

    public static void main(String[] args){
        // Task 5: create Complex objects, add or multiply them, and
        //         print the results out to check they are correct

    }


}
