public class Complex {

    // Task 3: add the missing fields
    double real;
    double imag;


    Complex(double real, double imag){
        // Task 4: complete the constructor
        this.real = real;
        this.imag = imag;

    }

    Complex add(Complex other){
        // Task 4: complete the method
        real=this.real + other.real;
        imag=this.imag + other.imag;
        return this;

    }

    Complex multiply(Complex other){
        // Task 4: complete the method
        real=this.real * other.real;
        imag=this.imag * other.imag;
        return this;

    }

    String asString(){
        // Task 4: complete the method
        String rea=String.valueOf(this.real);
        String ima=String.valueOf(this.imag);
        String res="("+rea+","+ima+")";
        return res;



    }

    public static void main(String[] args){
        // Task 5: create Complex objects, add or multiply them, and
        //         print the results out to check they are correct
        Complex a = new Complex(3,1);
        Complex b = new Complex(5,3);
        a.add(b);
        System.out.printf("%s",a.asString());

    }


}
