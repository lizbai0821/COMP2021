import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * Created by lizbai on 2/10/16.
 */
@RunWith(Suite.class)

@Suite.SuiteClasses({
        MiniFloatTest.class,
        MiniFloatTest2.class
})
public class TestSuite {
}
