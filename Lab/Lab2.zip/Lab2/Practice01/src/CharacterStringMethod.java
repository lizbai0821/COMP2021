/**
 * Created by lizbai on 17/9/16.
 */
public class CharacterStringMethod {
    public static void main(String args[]) {
        for (int i = 0; i < args.length; i++)
        {
            String temp = args[i]; // Do operations on each String in Command Line Arguments
            //Insert your code here

            /* Exercise #1
            Output the digits in Command Line Arguments
            by method 'isDigit'
             */

            /* Exercise #2
            Output the Command Line Arguments in upper case
            by method 'toUpperCase'
             */
        }
        /* Exercise #3
            Given three arguments: towards the first argument, output the index in it
            where the second and third argument appears firstly.
            E.g., Input-> Java va a
                  Output-> 2 1
            by method 'indexOf'
         */
    }
}
