/**
 * Created by lizbai on 7/9/16.
 */
import java.util.Random;

public class RabbitRace {

    public static void main(String[] args) {
        double positionRabbit = 0;
        double speedRabbit = 1.1;
        double probabilityRabbitRest = 0.5;
        final double COURSE_LENGTH = 11;

        int time = 0;
        while(positionRabbit < COURSE_LENGTH){
            if(!shouldRest(probabilityRabbitRest)){
                positionRabbit += speedRabbit;
            }
            time++;
        }

        System.out.println("The Rabbit finished the whole course in " + time + " time units.");

    }

    private static boolean shouldRest(double probability){
        Random random = new Random();
        double value = random.nextDouble();
        return value < probability;
    }

}
